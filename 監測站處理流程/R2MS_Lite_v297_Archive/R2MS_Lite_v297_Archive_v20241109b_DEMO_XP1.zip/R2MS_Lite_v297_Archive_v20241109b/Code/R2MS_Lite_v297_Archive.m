%**************************************************************************
%   Name: R2MS_Lite_v297_Archive.m v20241109b
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20241109b
%   Description: �����uR2MS_Lite�v�ѡuv297csv�v�k�ɪ��n��
%   �ϥΤ�k(MATLAB):
%           R2MS_Lite_v297_Archive('2024','07','..\DATA','..\[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)','XP1','S001')
%**************************************************************************
function R2MS_Lite_v297_Archive(Target_Archive_Year,Target_Archive_Month,v297_DATA_Folder,Project_Folder_Name,Project_Profile_Name,SwitchArray_SN)
% clear;clc;close all
% %--
% % �ؼЭn�k�ɪ��~��
% Target_Archive_Year='2024';%�榡:yyyy
% % �ؼЭn�k�ɪ����
% Target_Archive_Month='07';%�榡:mm
% %--
% v297_DATA_Folder='..\DATA';
% Project_Folder_Name='..\[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)';
% Project_Profile_Name='XP1';
% SwitchArray_SN='S001';
Archive_Log_json_version_str='v20241109b';
    %-----------------------------------------
    % �ϥ�dir�d�߸�Ƨ������M��
    temp_dir_result=dir(fullfile(v297_DATA_Folder,'*.csv'));
    % �u���X�ɮצW�٪��ӭM�x�}
    csv_file_list_cell={temp_dir_result(:).name}';
    %-----------------------------------------
    for i_csv_file_list_cell=1:length(csv_file_list_cell)        
        %disp(['�ˬd�ɮ�[',num2str(i_csv_file_list_cell),']:',csv_file_list_cell{i_csv_file_list_cell}])
        input_regexp_str=csv_file_list_cell{i_csv_file_list_cell};% �榡: 2024_07_01_20_01.csv
        input_regexp_expression=['\d{4}_\d{2}_\d{2}_\d{2}_\d{2}.csv'];
        [out_regexp_Match,out_regexp_noMatch] = regexp(input_regexp_str,input_regexp_expression,'match','split');
        if (length(out_regexp_Match)==1 && isempty(out_regexp_noMatch{1}) && isempty(out_regexp_noMatch{2}))
            %disp(['�ˬd�ɮ�[',num2str(i_csv_file_list_cell),']:',csv_file_list_cell{i_csv_file_list_cell},' =>�ɮ׮榡���T'])
             if (strcmp(csv_file_list_cell{i_csv_file_list_cell}(1:8),[Target_Archive_Year,'_',Target_Archive_Month,'_']))
                disp('++')
                disp(['�ˬd�ɮ�[',num2str(i_csv_file_list_cell),']:',csv_file_list_cell{i_csv_file_list_cell},' =>�ŦX���w�~���'])      
                
                %-----------------------------------------
                % �d�ݦ��S���B������ɮסA�M�w�O�_�n�A���k��
                need_Archive=1;%0=�����k�ɡA1=�n�k��
                %--
                % �B��O���ɮצW��
                Output_Archive_Log_filename=...
                    fullfile(Project_Folder_Name,... %[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)
                    'Recorder',...
                    Project_Profile_Name,...%XP1
                    csv_file_list_cell{i_csv_file_list_cell}(1:4),...%2024
                    csv_file_list_cell{i_csv_file_list_cell}(6:7),...%08
                    csv_file_list_cell{i_csv_file_list_cell}(9:10),...%01
                    [csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16]),'.json']...%2001
                    );
                %--
                % �ˬd�ɮ׬O�_�s�b
                if (exist(Output_Archive_Log_filename,'file')==2)
                    %-----------------------------------------
                    %disp('�ɮצs�b!')
                    %--
                    % Ū��
                    f1 = fopen(Output_Archive_Log_filename,'r');
                    if (f1<0)
                        disp('���~!�}���ɮץ���!�гq���޲z��!�v�����D��?')
                        return
                    end
                    temp_str = fread(f1, '*char')';
                    %disp(temp_str)
                    fclose(f1);
                    %-----------------------------------------
                    % ���R�B�@����
                    %--
                    % JSON�r���൲�c��
                    temp_json=json_decode(temp_str);
                    %--
                    % �ˬd���c�����O�_�s�b
                    if (isfield(temp_json,'FileName'))
                        %disp('JSON����FileName���')
                        %disp(temp_json.FileName)
                        %--
                        % ²�����Ҥ��e
                        if strcmp(temp_json.FileName,[csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16]),'.zip'])
                            %disp('JSON�����ɦW�P�ؼ��ɦW�۲ŦX!�q�L����!���ܤw�g�k�ɹL!')
                            need_Archive=0;%0=�����k�ɡA1=�n�k��
                        end
                        %--
                    end
                    %-----------------------------------------                    
                else
                    %disp('�ɮפ��s�b!')
                end
                %-----------------------------------------
                if (need_Archive==1)
                    disp('�ݭn�i���k��...')
                    %-----------------------------------------
                    % �k��(���ɻP���s�վ��Ƨ����c�èϥέ��ɮ׮ɶ��W)
                    %--
                    % �ǳƿ�J�ɮצW��
                    Input_R2MS_Lite_v297rawcsv_filename=fullfile(v297_DATA_Folder,csv_file_list_cell{i_csv_file_list_cell});         
                    %--
                    % �ǳƿ�X�ɮצW��
                    Output_R2MS_Lite_v297csv_folder=...
                        fullfile(Project_Folder_Name,... %[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)
                        'Recorder',...
                        Project_Profile_Name,...%XP1
                        csv_file_list_cell{i_csv_file_list_cell}(1:4),...%2024
                        csv_file_list_cell{i_csv_file_list_cell}(6:7),...%08
                        csv_file_list_cell{i_csv_file_list_cell}(9:10),...%01
                        csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16]),...%2001
                        'Part01',...
                        '1');
                    Output_R2MS_Lite_v297csv_filename=...
                        [SwitchArray_SN,... %S001
                        csv_file_list_cell{i_csv_file_list_cell}(1:4),...%2024
                        csv_file_list_cell{i_csv_file_list_cell}(6:7),...%08
                        csv_file_list_cell{i_csv_file_list_cell}(9:10),...%01
                        csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16])...%2001
                        ];     
                    %--
                    % ���ɨæs�J���w��m
                    R2MS_Lite_v297rawcsv_to_v297csv(Input_R2MS_Lite_v297rawcsv_filename,Output_R2MS_Lite_v297csv_folder,Output_R2MS_Lite_v297csv_filename)
                    %--
                    % �ϥ�PowerShell�վ�إߤ��
                    cmd_str=['PowerShell "(Get-Item -LiteralPath ''',fullfile(Output_R2MS_Lite_v297csv_folder,[Output_R2MS_Lite_v297csv_filename,'.v297.csv']),''').CreationTime=(Get-Item -LiteralPath ''',Input_R2MS_Lite_v297rawcsv_filename,''').CreationTime"'];
                    system(cmd_str);
                    % �ϥ�PowerShell�վ�ק���
                    cmd_str=['PowerShell "(Get-Item -LiteralPath ''',fullfile(Output_R2MS_Lite_v297csv_folder,[Output_R2MS_Lite_v297csv_filename,'.v297.csv']),''').LastWriteTime=(Get-Item -LiteralPath ''',Input_R2MS_Lite_v297rawcsv_filename,''').LastWriteTime"'];
                    system(cmd_str);
                    % �ϥ�PowerShell�վ�̫�X�ݤ��
                    cmd_str=['PowerShell "(Get-Item -LiteralPath ''',fullfile(Output_R2MS_Lite_v297csv_folder,[Output_R2MS_Lite_v297csv_filename,'.v297.csv']),''').LastAccessTime=(Get-Item -LiteralPath ''',Input_R2MS_Lite_v297rawcsv_filename,''').LastAccessTime"'];
                    system(cmd_str);    
                    %--
                    % �p��zip�ɮפj�p
                    temp_dir_result=dir(fullfile(Output_R2MS_Lite_v297csv_folder,[Output_R2MS_Lite_v297csv_filename,'.v297.csv'])); 
                    target_v297csv_name=temp_dir_result.name;
                    target_v297csv_bytes=temp_dir_result.bytes;
                    disp([target_v297csv_name,' bytes = ',sprintf('%d',target_v297csv_bytes)])    
                    %-----------------------------------------
                    % ���Y���w��Ƨ����e
                    %--
                    % ���Y���ɦW
                    Compressed_zip_name=...
                        fullfile(Project_Folder_Name,... %[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)
                        'Recorder',...
                        Project_Profile_Name,...%XP1
                        csv_file_list_cell{i_csv_file_list_cell}(1:4),...%2024
                        csv_file_list_cell{i_csv_file_list_cell}(6:7),...%08
                        csv_file_list_cell{i_csv_file_list_cell}(9:10),...%01
                        [csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16]),'.zip']...%2001
                        );
                    %--
                    % �n���Y���ؿ�
                    want_Compress_folder_name=...
                        fullfile(Project_Folder_Name,... %[20240409A]Taiwan-Taipei-XiaoYouKengScenicPlatform(XYKP)
                        'Recorder',...
                        Project_Profile_Name,...%XP1
                        csv_file_list_cell{i_csv_file_list_cell}(1:4),...%2024
                        csv_file_list_cell{i_csv_file_list_cell}(6:7),...%08
                        csv_file_list_cell{i_csv_file_list_cell}(9:10),...%01
                        csv_file_list_cell{i_csv_file_list_cell}([12,13,15,16])...%2001
                        );
                    %--
                    % �i�����Y
                    zip(Compressed_zip_name,'',want_Compress_folder_name)
                    %--
                    % �R�������Y�����
                    [status, message, messageid] = rmdir(want_Compress_folder_name, 's');
                    %-----------------------------------------
                    % �p��zip�ɮפj�p
                    temp_dir_result=dir(Compressed_zip_name); 
                    target_zip_name=temp_dir_result.name;
                    target_zip_bytes=temp_dir_result.bytes;
                    disp([target_zip_name,' bytes = ',sprintf('%d',target_zip_bytes)])               
                    %-----------------------------------------                
                    % �p��MD5�����X
                    md5hash = yeh_MD5_checksum(Compressed_zip_name);
                    if (isempty(md5hash.Error.String))
                        disp([target_zip_name,' md5 = ',md5hash.String])
                    else
                        disp(md5hash.Error.String)
                    end        
                    %-----------------------------------------
                    % �B��O���ɮ�
                    Archive_Log.Software='R2MS_Lite_v297_Archive';
                    Archive_Log.Version=Archive_Log_json_version_str;
                    [temp_path,temp_name,temp_ext]=fileparts(Project_Folder_Name);
					Archive_Log.ProjectName=temp_name;
					Archive_Log.ProfileName=Project_Profile_Name;
					Archive_Log.AcquisitionYear=csv_file_list_cell{i_csv_file_list_cell}(1:4);
					Archive_Log.AcquisitionMonth=csv_file_list_cell{i_csv_file_list_cell}(6:7);
					Archive_Log.AcquisitionDay=csv_file_list_cell{i_csv_file_list_cell}(9:10);
                    Archive_Log.FileName=target_zip_name;
                    Archive_Log.FileBytes=sprintf('%d',target_zip_bytes);
                    Archive_Log.FileMD5=md5hash.String;
                    Archive_Log.FileUpload='Ready';%Ready=�ǳƤW�ǡAFail=�W�ǥ��ѡAOK=�W�Ǧ��\
                    Archive_Log.v297csvFileName=[Output_R2MS_Lite_v297csv_filename,'.v297.csv'];
                    Archive_Log.v297csvBytes=sprintf('%d',target_v297csv_bytes);
                    %disp(json_encode(Archive_Log));
                    %--
                    % �s��
                    Output_Archive_Log_filename=[Compressed_zip_name(1:end-4),'.json'];
                    f1 = fopen(Output_Archive_Log_filename,'w');
                    fprintf(f1,'%s',json_encode(Archive_Log));
                    fclose(f1);
                    %--
                    disp('++')       
                    %-----------------------------------------
                else
                    disp('���ݭn�i���k��...���L')
                    disp('++')  
                end
            end
        end
    end

    disp('Done!')
end