%**************************************************************************
%   Name: Main.m v20241110a
%   Copyright:  
%   Author: HsiupoYeh 
%   Version: v20241110a
%   Description: R2MS_Lite_v297_Upload���I�s�d�ҡC
%   �ݨD: 
%   Main.m                           
%   R2MS_Lite_v297_Upload.m v20241110a        
%   json_decode.m                    
%   json_decode.mexw64               
%   json_encode.m                    
%   json_encode.mexw64               
%   curl.exe
%   curl-ca-bundle.crt
%   libcurl-x64.dll
%   yeh_ini2struct_ansi.m    
%**************************************************************************
clear;clc;close all
% �D�{���Ѽ�INI�ɮצ�m
main_ini_full_file_name='Input_ini\R2MS_Lite_v297_Upload.ini';
% ���XINI�Ѽ�
IniFile=yeh_ini2struct_ansi(main_ini_full_file_name);
% �I�s
R2MS_Lite_v297_Upload(...
    IniFile.Struct.R2MS_Lite_v297_Upload.Target_Archive_Year,...
    IniFile.Struct.R2MS_Lite_v297_Upload.Target_Archive_Month,...
    IniFile.Struct.R2MS_Lite_v297_Upload.Project_Folder_Name,...
    IniFile.Struct.R2MS_Lite_v297_Upload.Project_Profile_Name,...
    IniFile.Struct.R2MS_Lite_v297_Upload.DataCenter_IP,...
    IniFile.Struct.R2MS_Lite_v297_Upload.Always_Try_Upload);
