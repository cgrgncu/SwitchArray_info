@echo off
setlocal
if exist "C:\Program Files\Go\bin\go.exe" set "PATH=C:\Program Files\Go\bin;%PATH%"
cd /d "%~dp0src"
if exist "%USERPROFILE%\go\bin\rsrc.exe" (
    "%USERPROFILE%\go\bin\rsrc.exe" -ico "..\icon\R2MS_Lite_CSV_CurrentQC.ico" -o "rsrc.syso" >nul 2>&1
)
go build -o "..\exe\R2MS_Lite_CSV_CurrentQC.exe" .
if %errorlevel% neq 0 (
    echo Build failed.
    exit /b %errorlevel%
)
echo Build succeeded: R2MS_Lite_CSV_CurrentQC.exe
endlocal