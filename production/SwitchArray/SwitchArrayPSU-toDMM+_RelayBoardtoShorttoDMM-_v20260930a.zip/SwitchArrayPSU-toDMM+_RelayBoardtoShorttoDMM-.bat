.\PythonEnv\Python.exe SwitchArrayPSU-toDMM+_RelayBoardtoShorttoDMM-.py
PAUSE