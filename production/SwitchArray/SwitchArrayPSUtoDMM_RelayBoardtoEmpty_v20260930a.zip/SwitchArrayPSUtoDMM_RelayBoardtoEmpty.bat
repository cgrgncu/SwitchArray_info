.\PythonEnv\Python.exe SwitchArrayPSUtoDMM_RelayBoardtoEmpty.py
PAUSE