.\PythonEnv\Python.exe SwitchArrayDMMtoDMM_RelayBoardtoEmpty.py
PAUSE