# **************************************************************************#
#   Name: SwitchArrayDMMtoDMM_RelayBoardtoEmpty.py
#   Copyright: 
#   Author: HsiupoYeh
#   Version: v20261001a
#   Description: 自動化硬體檢測程式：利用 DMM 檢測 SwitchArray 目標電阻功能。
#                產出「SwitchArray 小顆繼電器自動化測試報告」
# ==========================================================================#
# 【重要：硬體接線】
# 1. 「SwitchArray」用「DMM連接線(紅、黑)_香蕉接頭轉電錶接頭」連接到「DMM」：
#    - 紅色線接到DMM右邊上面第1個孔(紅色)。
#    - 黑色線接到DMM右邊上面第2個孔(黑色)。
# 2. 「SwitchArray」用「USB」連接到「PC」。
# 3. 「SwitchArray」的「RelayBoard」維持空接。
# **************************************************************************#

import ctypes
import html
import json
import subprocess
import sys
import time

# ==========================================
# 【啟動時印出作者與接線資訊】
# ==========================================
print("**************************************************************************")
print("   Name: SwitchArrayDMMtoDMM_RelayBoardtoEmpty.py")
print("   Author: HsiupoYeh")
print("   Version: v20261001a")
print("   Description: 自動化硬體檢測程式：利用 DMM 檢測 SwitchArray 目標電阻功能。")
print("                產出「SwitchArray 小顆繼電器自動化測試報告」")
print("--")
print(" 【重要：硬體接線】")
print(" 1. 「SwitchArray」用「DMM連接線(紅、黑)_香蕉接頭轉電錶接頭」連接到「DMM」：")
print("    - 紅色線接到DMM右邊上面第1個孔(紅色)。")
print("    - 黑色線接到DMM右邊上面第2個孔(黑色)。")
print(" 2. 「SwitchArray」用「USB」連接到「PC」。")
print(" 3. 「SwitchArray」的「RelayBoard」維持空接。")
print("**************************************************************************\n")

# ==========================================
# 【使用者設定區】在這裡自由編輯操作順序與模式
# ==========================================

# DEBUG_LEVEL 控制顯示模式：
# - 1: 顯示詳細的運作過程 (包含階段檢索、詳細通訊過程與 Log)
# - 0: 顯示精簡版的測試結果 (隱藏過程 Log，即時在畫面上呈現精簡狀態與終端機文字表格)
DEBUG_LEVEL = 0

# 定義目標電阻的檢測規格範圍 (單位: Ω)
TARGET_RES_MIN = 50
TARGET_RES_MAX = 51

Supported_ESP32_SN = [
    "2025-S000",
    "2025-S001",
    "2025-S002",
    "2025-S003",
    "2025-S004",
    "2025-S005",
    "2025-S006",
    "2026-S000",
    "2026-S007",
    "2026-S008",
    "2026-S009",
    "2026-S010",
]

Supported_DMM_SN = [
    "MY59004074",
    "MY60077634",
    "MY60090449",
    "MY60076563",
    "MY60078728",
    "MY60681084",
    "MY64001649",
    "MY64004458",
]

# ==============================================================================
# 【指令清單與範圍設定說明】
# 1. COMMAND_PLATES 與 COMMAND_LEDS：控制指令產生的板子與 LED 範圍。
# 2. REPORT_PLATES 與 REPORT_LEDS：控制 HTML 報表解析與讀取的板子與 LED 範圍。
# ==============================================================================

COMMAND_PLATES = [1,2,3,4,5,6,7,8]
REPORT_PLATES = COMMAND_PLATES

COMMAND_LEDS = [1,2,3,4,5,6,7,8]
REPORT_LEDS = COMMAND_LEDS

Command_Delay_in_second = 0.05

Command_List = [
    # 初始步驟：確定全部關閉後為開路
    {"type": "esp32", "url": "http://192.168.4.1/global?state=0", "notes": "Step 0: All Off"},
    {"type": "dmm"},
]

# 迴圈自動產生測試項目（順序：Case 1 -> Case 2 -> Case 3，改為使用 Row 4 與 Row 3）
for plate_id in COMMAND_PLATES:
    for led_id in COMMAND_LEDS:
        # Group Case 1 (單獨開 Row 4，預期開路)
        Command_List.append({"type": "esp32", "url": "http://192.168.4.1/global?state=0", "notes": f"Plate {plate_id} LED {led_id} - Case 1: All Off"})
        Command_List.append({"type": "esp32", "url": f"http://192.168.4.1/control?plate={plate_id}&row=4&led={led_id}&state=1", "notes": f"Plate {plate_id} LED {led_id} - Case 1: Plate{plate_id}-Row4-LED{led_id} ON"})
        Command_List.append({"type": "dmm"})  
        
        # Group Case 2 (同時開 Row 3 與 Row 4，預期導通目標範圍)
        Command_List.append({"type": "esp32", "url": "http://192.168.4.1/global?state=0", "notes": f"Plate {plate_id} LED {led_id} - Case 2: All Off"})
        Command_List.append({"type": "esp32", "url": f"http://192.168.4.1/control?plate={plate_id}&row=3&led={led_id}&state=1", "notes": f"Plate {plate_id} LED {led_id} - Case 2: Plate{plate_id}-Row3-LED{led_id} ON"})
        Command_List.append({"type": "esp32", "url": f"http://192.168.4.1/control?plate={plate_id}&row=4&led={led_id}&state=1", "notes": f"Plate {plate_id} LED {led_id} - Case 2: Plate{plate_id}-Row4-LED{led_id} ON"})
        Command_List.append({"type": "dmm"})
    
        # Group Case 3 (單獨開 Row 3，預期開路)
        Command_List.append({"type": "esp32", "url": "http://192.168.4.1/global?state=0", "notes": f"Plate {plate_id} LED {led_id} - Case 3: All Off"})
        Command_List.append({"type": "esp32", "url": f"http://192.168.4.1/control?plate={plate_id}&row=3&led={led_id}&state=1", "notes": f"Plate {plate_id} LED {led_id} - Case 3: Plate{plate_id}-Row3-LED{led_id} ON"})
        Command_List.append({"type": "dmm"})

# ==========================================
# 【階段一】透過 WMI 查詢裝置並比對序號
# ==========================================
if DEBUG_LEVEL >= 1:
    print("=========================================================")
    print(" [階段一] 硬體裝置檢索與序號比對")
    print("=========================================================")

target_com_port = None
target_dmm_sn = None

ps_script = 'Get-CimInstance Win32_PnPEntity | Select-Object Caption, Description, DeviceID, PNPClass | ConvertTo-Json'
result = subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], capture_output=True, text=True)

if result.returncode != 0 or not result.stdout.strip():
    print("[錯誤] 未能取得系統 PnP 裝置資料，程式停止。")
    sys.exit()

try:
    data = json.loads(result.stdout)
    if isinstance(data, dict): data = [data]
    for dev in data:
        caption = dev.get("Caption") or ""
        description = dev.get("Description") or ""
        device_id = dev.get("DeviceID") or ""
        sn = device_id.split("\\")[-1] if device_id else ""

        if "Silicon Labs CP210x USB to UART Bridge" in description:
            if sn in Supported_ESP32_SN:
                com_port = "Unknown"
                if "(" in caption and ")" in caption:
                    com_port = caption.split("(")[-1].split(")")[0]
                target_com_port = com_port
                if DEBUG_LEVEL >= 1:
                    print(f"    [配對成功] SwitchArray  |  SN: {sn:<12} |  Port: {com_port}")

        if "USB\\VID_2A8D&PID_0101\\" in device_id:
            if sn in Supported_DMM_SN:
                target_dmm_sn = sn
                if DEBUG_LEVEL >= 1:
                    print(f"    [配對成功] DMM 儀器     |  SN: {sn}")
except Exception as e:
    print(f"[錯誤] 解析 WMI 資料失敗: {e}")
    sys.exit()

if not target_com_port or not target_dmm_sn:
    print("\n[錯誤] 未能完整找到目標硬體裝置！")
    sys.exit()

if DEBUG_LEVEL >= 1:
    print(" > 階段一完成\n" + "-" * 57)

# ==========================================
# 【階段二】初始化硬體連線
# ==========================================
if DEBUG_LEVEL >= 1:
    print(" [階段二] 初始化硬體連線")

kernel32 = ctypes.windll.kernel32
GENERIC_READ, GENERIC_WRITE, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, INVALID_HANDLE_VALUE = 0x80000000, 0x40000000, 3, 0x00000080, -1

port_name = f"\\\\.\\{target_com_port}"
h_serial = kernel32.CreateFileW(port_name, GENERIC_READ | GENERIC_WRITE, 0, None, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, None)
if h_serial == INVALID_HANDLE_VALUE:
    print(f"[錯誤] 無法開啟 ESP32 COM 埠 ({target_com_port})")
    sys.exit()

visa = ctypes.CDLL("visa64.dll")
rm = ctypes.c_ulong()
session = ctypes.c_ulong()
visa.viOpenDefaultRM(ctypes.byref(rm))
instrument_address_bytes = f"USB0::0x2A8D::0x0101::{target_dmm_sn}::0::INSTR".encode("utf-8")
visa.viOpen(rm, instrument_address_bytes, 0, 0, ctypes.byref(session))

ret_count = ctypes.c_ulong()
dmm_buffer = ctypes.create_string_buffer(256)
visa.viWrite(session, b"*RST; *OPC?\n", 12, ctypes.byref(ret_count))
visa.viRead(session, dmm_buffer, 256, ctypes.byref(ret_count))
time.sleep(0.5)

# 設定固定 100 歐姆量程以加快量測速度
visa.viWrite(session, b"CONF:RES 100; *OPC?\n", 19, ctypes.byref(ret_count))
visa.viRead(session, dmm_buffer, 256, ctypes.byref(ret_count))

# 執行幾次無用量測 (Dummy Reads) 進行儀器熱機
for _ in range(3):
    visa.viWrite(session, b"READ?\n", 6, ctypes.byref(ret_count))
    visa.viRead(session, dmm_buffer, 256, ctypes.byref(ret_count))

if DEBUG_LEVEL >= 1:
    print(" > 階段二完成\n" + "-" * 57)

# ==========================================
# 【階段三】執行自動化操作清單
# ==========================================
if DEBUG_LEVEL >= 1:
    print(" [階段三] 執行自動化操作清單")
else:
    print(f"[執行中] 自動化量測進行中 (ESP32: {target_com_port}, DMM: {target_dmm_sn})...\n")

report_records = []

try:
    total_tasks = len(Command_List)
    for idx, task in enumerate(Command_List, 1):
        task_type = task.get("type")

        if task_type == "esp32":
            url = task.get("url")
            notes = task.get("notes", "")
            json_obj = {"url": url}
            if notes: json_obj["Notes"] = notes

            cmd_str = json.dumps(json_obj)
            command_bytes = (cmd_str + "\n").encode("utf-8")
            bytes_written = ctypes.c_ulong(0)
            note_str = f" [{notes}]" if notes else ""

            if DEBUG_LEVEL >= 1:
                print(f"\n({idx}/{total_tasks}){note_str} ESP32 指令")

            kernel32.WriteFile(h_serial, command_bytes, len(command_bytes), ctypes.byref(bytes_written), None)
            time.sleep(Command_Delay_in_second)

            buffer = ctypes.create_string_buffer(256)
            bytes_read = ctypes.c_ulong(0)
            success = kernel32.ReadFile(h_serial, buffer, 256, ctypes.byref(bytes_read), None)
            response = buffer.raw[:bytes_read.value].decode("utf-8", errors="ignore").strip() if (success and bytes_read.value > 0) else "(無資料返回)"
            
            if DEBUG_LEVEL >= 1:
                print(f"  -> 回應: {response}")

            report_records.append({
                "step": f"({idx}/{total_tasks})",
                "action": f"ESP32: {notes}" if notes else "ESP32 指令",
                "result": f"回應: {response}"
            })

        elif task_type == "dmm":
            if DEBUG_LEVEL >= 1:
                print(f"\n({idx}/{total_tasks}) DMM 電阻量測 (READ?)")

            visa.viWrite(session, b"READ?\n", 6, ctypes.byref(ret_count))
            visa.viRead(session, dmm_buffer, 256, ctypes.byref(ret_count))
            
            raw_value = dmm_buffer.raw[:ret_count.value].decode("utf-8", errors="ignore").strip() if ret_count.value > 0 else ""

            result_str = ""
            try:
                if not raw_value:
                    result_str = "(無資料)"
                else:
                    val = float(raw_value)
                    if val > 1e30:
                        result_str = "開路"
                        if DEBUG_LEVEL >= 1: print("  -> 結果: 開路")
                    else:
                        result_str = f"{val:.4f} Ω"
                        if DEBUG_LEVEL >= 1: print(f"  -> 結果: {val:.4f} Ω")
            except ValueError:
                result_str = raw_value if raw_value else "(解析錯誤)"
                if DEBUG_LEVEL >= 1: print(f"  -> 結果 (原始): {raw_value}")

            report_records.append({
                "step": f"({idx}/{total_tasks})",
                "action": "DMM 電阻量測",
                "result": result_str
            })

            # 若為精簡模式 (DEBUG_LEVEL == 0)，即時在畫面上印出結構化測試結果摘要
            if DEBUG_LEVEL == 0:
                dmm_count = sum(1 for r in report_records if "DMM" in r["action"])
                if dmm_count == 1:
                    s0_pass = "開路" in result_str
                    print(f"[Step 0] 全關閉初始檢查 -> 結果: {result_str:<12} | 判定: {'PASS' if s0_pass else 'FAIL'}")
                elif dmm_count > 1:
                    remainder = (dmm_count - 1) % 3
                    if remainder == 0:
                        dmm_results = [r["result"] for r in report_records if "DMM" in r["action"]]
                        c3 = result_str
                        c2 = dmm_results[-2]
                        c1 = dmm_results[-3]
                        
                        c1_pass = "開路" in c1
                        c3_pass = "開路" in c3
                        c2_pass = False
                        try:
                            val = float(c2.split(" ")[0])
                            if TARGET_RES_MIN <= val <= TARGET_RES_MAX:
                                c2_pass = True
                        except:
                            pass
                        
                        group_pass = c1_pass and c2_pass and c3_pass
                        p_text = 'PASS' if group_pass else 'FAIL'
                        
                        current_index = (dmm_count - 2) // 3
                        p_idx = COMMAND_PLATES[current_index // len(COMMAND_LEDS)]
                        l_idx = COMMAND_LEDS[current_index % len(COMMAND_LEDS)]
                        
                        print(f"[Plate {p_idx}] LED {l_idx} 測試 | Case 1: {c1:<8} | Case 2: {c2:<12} | Case 3: {c3:<8} | 最終判定: {p_text}")

            time.sleep(Command_Delay_in_second)

    if DEBUG_LEVEL >= 1:
        print("\n" + "-" * 57 + "\n 階段三完成")

finally:
    # ==========================================
    # 【階段四】關閉連線與產出分頁式 HTML 報告
    # ==========================================
    try:
        kernel32.CloseHandle(h_serial)
        visa.viClose(session)
        visa.viClose(rm)
    except Exception:
        pass

    try:
        # 提取 DMM 測量結果
        dmm_results = [r["result"] for r in report_records if "DMM" in r["action"]]
        
        step0_val = dmm_results[0] if len(dmm_results) > 0 else "N/A"
        step0_pass = "開路" in step0_val
        
        groups_summary = []
        dmm_idx = 1
        
        # 依照 REPORT_PLATES 與 REPORT_LEDS 進行資料解析與 Pass/Fail 判定
        for plate_id in REPORT_PLATES:
            for led_id in REPORT_LEDS:
                c1 = dmm_results[dmm_idx] if dmm_idx < len(dmm_results) else "N/A"
                c2 = dmm_results[dmm_idx+1] if dmm_idx+1 < len(dmm_results) else "N/A"
                c3 = dmm_results[dmm_idx+2] if dmm_idx+2 < len(dmm_results) else "N/A"
                dmm_idx += 3
                
                # 判定邏輯：Case 1, 3 需開路；Case 2 需在 TARGET_RES_MIN ~ TARGET_RES_MAX 之間
                c1_pass = "開路" in c1
                c3_pass = "開路" in c3
                
                c2_pass = False
                try:
                    val = float(c2.split(" ")[0])
                    if TARGET_RES_MIN <= val <= TARGET_RES_MAX:
                        c2_pass = True
                except:
                    pass
                
                group_pass = c1_pass and c2_pass and c3_pass
                groups_summary.append({
                    "plate": f"Plate {plate_id}",
                    "group": f"LED {led_id} 測試",
                    "c1": c1, "c1_pass": c1_pass,
                    "c2": c2, "c2_pass": c2_pass,
                    "c3": c3, "c3_pass": c3_pass,
                    "pass": group_pass
                })

        # 若設定為精簡模式 (DEBUG_LEVEL == 0)，在終端機印出文字對齊總結表格
        if DEBUG_LEVEL == 0:
            c2_header_str = f"Case 2 ({TARGET_RES_MIN}~{TARGET_RES_MAX}Ω)"
            col_width_c2 = max(18, len(c2_header_str) + 2)
            print("\n" + "=" * 85)
            print(" 【即時測試結果摘要表】")
            print("=" * 85)
            print(f"{'測試板子':<12} | {'測試項目':<15} | {'Case 1 (開路)':<15} | {c2_header_str:<{col_width_c2}} | {'Case 3 (開路)':<15} | {'最終判定':<8}")
            print("-" * 85)
            step0_status_str = "PASS" if step0_pass else "FAIL"
            print(f"{'-':<12} | {'Step 0 (全關閉)':<15} | {step0_val:<15} | {'-':<{col_width_c2}} | {'-':<15} | {step0_status_str:<8}")
            for gs in groups_summary:
                p_text = 'PASS' if gs["pass"] else 'FAIL'
                print(f"{gs['plate']:<12} | {gs['group']:<15} | {gs['c1']:<15} | {gs['c2']:<{col_width_c2}} | {gs['c3']:<15} | {p_text:<8}")
            print("=" * 85)

        # 產生詳細過程表格列 (HTML 用)
        detail_rows_html = ""
        for record in report_records:
            res_esc = html.escape(record["result"])
            badge = "badge-info"
            if "OK" in res_esc: badge = "badge-success"
            elif "開路" in res_esc: badge = "badge-warning"
            elif "Ω" in res_esc: badge = "badge-primary"
            
            detail_rows_html += f"""
                <tr>
                    <td><code>{record["step"]}</code></td>
                    <td>{html.escape(record["action"])}</td>
                    <td><span class="badge {badge}">{res_esc}</span></td>
                </tr>
            """

        # 產生主要摘要表格列 (HTML 用)
        summary_rows_html = f"""
            <tr class="{'table-success' if step0_pass else 'table-danger'}">
                <td>-</td>
                <td><strong>Step 0 (全關閉初始檢查)</strong></td>
                <td colspan="3"><span class="badge {'badge-warning' if step0_pass else 'badge-danger'}">{step0_val}</span></td>
                <td><span class="status-pill {'status-pass' if step0_pass else 'status-fail'}">{'PASS' if step0_pass else 'FAIL'}</span></td>
            </tr>
        """
        for gs in groups_summary:
            p_badge = 'status-pass' if gs["pass"] else 'status-fail'
            p_text = 'PASS' if gs["pass"] else 'FAIL'
            summary_rows_html += f"""
                <tr>
                    <td><strong>{gs["plate"]}</strong></td>
                    <td><strong>{gs["group"]}</strong></td>
                    <td><span class="badge {'badge-warning' if gs["c1_pass"] else 'badge-danger'}">{gs["c1"]}</span></td>
                    <td><span class="badge {'badge-primary' if gs["c2_pass"] else 'badge-danger'}">{gs["c2"]}</span></td>
                    <td><span class="badge {'badge-warning' if gs["c3_pass"] else 'badge-danger'}">{gs["c3"]}</span></td>
                    <td><span class="status-pill {p_badge}">{p_text}</span></td>
                </tr>
            """

        # HTML 模板
        html_content = f"""<!DOCTYPE html>
        <html lang="zh-Hant">
        <head>
            <meta charset="UTF-8">
            <title>SwitchArray 小顆繼電器自動化測試報告</title>
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: #f8f9fa; color: #333; margin: 0; padding: 20px; }}
                .container {{ max-width: 1150px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }}
                h1 {{ font-size: 24px; color: #2c3e50; margin-top: 0; }}
                .meta {{ color: #6c757d; font-size: 14px; margin-bottom: 20px; }}
                
                /* 頁籤 Tab 樣式 */
                .tabs {{ display: flex; border-bottom: 2px solid #dee2e6; margin-bottom: 20px; }}
                .tab-btn {{ padding: 10px 20px; cursor: pointer; border: none; background: none; font-size: 16px; font-weight: 600; color: #6c757d; outline: none; }}
                .tab-btn.active {{ color: #007bff; border-bottom: 3px solid #007bff; margin-bottom: -2px; }}
                .tab-content {{ display: none; }}
                .tab-content.active {{ display: block; }}

                /* 表格通用 */
                table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
                th, td {{ padding: 10px 12px; text-align: left; border-bottom: 1px solid #e9ecef; font-size: 14px; }}
                th {{ background-color: #f1f3f5; color: #495057; font-weight: 600; }}
                tr:hover {{ background-color: #f8f9fa; }}
                
                .badge {{ display: inline-block; padding: 4px 8px; font-size: 12px; font-weight: 500; border-radius: 4px; }}
                .badge-success {{ background-color: #d4edda; color: #155724; }}
                .badge-warning {{ background-color: #fff3cd; color: #856404; }}
                .badge-primary {{ background-color: #cce5ff; color: #004085; }}
                .badge-info {{ background-color: #e2e3e5; color: #383d41; }}
                .badge-danger {{ background-color: #f8d7da; color: #721c24; }}
                
                .status-pill {{ padding: 4px 12px; border-radius: 12px; font-weight: bold; font-size: 12px; }}
                .status-pass {{ background-color: #d4edda; color: #155724; }}
                .status-fail {{ background-color: #f8d7da; color: #721c24; }}
                code {{ background: #f1f3f5; padding: 2px 6px; border-radius: 4px; font-family: monospace; }}
            </style>
            <script>
                function switchTab(evt, tabId) {{
                    var contents = document.getElementsByClassName("tab-content");
                    for (var i = 0; i < contents.length; i++) {{ contents[i].classList.remove("active"); }}
                    var buttons = document.getElementsByClassName("tab-btn");
                    for (var i = 0; i < buttons.length; i++) {{ buttons[i].classList.remove("active"); }}
                    document.getElementById(tabId).classList.add("active");
                    evt.currentTarget.classList.add("active");
                }}
            </script>
        </head>
        <body>
            <div class="container">
                <h1>SwitchArray 小顆繼電器自動化測試報告</h1>
                <div class="meta">執行時間：{time.strftime("%Y-%m-%d %H:%M:%S")} | ESP32 SN：{target_com_port} | DMM SN：{target_dmm_sn} | 目標規格：{TARGET_RES_MIN} ~ {TARGET_RES_MAX} Ω | 系統狀態：完成</div>

                <!-- 頁籤按鈕 -->
                <div class="tabs">
                    <button class="tab-btn active" onclick="switchTab(event, 'tab-summary')">主要測試結果 (Summary)</button>
                    <button class="tab-btn" onclick="switchTab(event, 'tab-detail')">詳細執行過程 (Detailed Logs)</button>
                </div>

                <!-- 頁籤一：主要測試結果 -->
                <div id="tab-summary" class="tab-content active">
                    <p>此頁面顯示測試項目的量測結果摘要，並自動比對規格（開路 vs {TARGET_RES_MIN} ~ {TARGET_RES_MAX} Ω 導通）。</p>
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 15%;">測試板子</th>
                                <th style="width: 25%;">測試項目</th>
                                <th style="width: 15%;">Case 1 (預期: 開路)</th>
                                <th style="width: 15%;">Case 2 (預期: {TARGET_RES_MIN}~{TARGET_RES_MAX} Ω)</th>
                                <th style="width: 15%;">Case 3 (預期: 開路)</th>
                                <th style="width: 15%;">最終判定</th>
                            </tr>
                        </thead>
                        <tbody>
                            {summary_rows_html}
                        </tbody>
                    </table>
                </div>

                <!-- 頁籤二：詳細執行過程 -->
                <div id="tab-detail" class="tab-content">
                    <p>完整執行步驟的底層通訊與指令執行記錄。</p>
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 15%;">進度</th>
                                <th style="width: 50%;">動作 / 指令說明</th>
                                <th style="width: 35%;">執行回應結果</th>
                            </tr>
                        </thead>
                        <tbody>
                            {detail_rows_html}
                        </tbody>
                    </table>
                </div>

            </div>
        </body>
        </html>
        """

        # 動態產生對應時間戳記的報告檔名
        timestamp_str = time.strftime("%Y%m%d%H%M%S")
        report_filename = f"SwitchArrayDMMtoDMM_RelayBoardtoEmptyReport_{timestamp_str}.html"

        with open(report_filename, "w", encoding="utf-8") as f:
            f.write(html_content)

        print(f"\n > 測試報告已成功產出：{report_filename}")

    except Exception as e:
        print(f"  [錯誤] 產生 HTML 報告失敗: {e}")

    print("\n=========================================================\n 程式完全結束。\n=========================================================")