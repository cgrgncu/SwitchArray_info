# R2MS_Lite_CSV_CurrentQC

分析 R2MS_Lite CSV 檔案的通道電流 (CH01~CH64) 與 Rx 電流比較，產出 QC 報告 (HTML) 與摘要 (Markdown)。

## 結構

- `src/main.go` — 主程式原始碼
- `src/go.mod` — Go 模組定義
- `src/rsrc.syso` — 圖示資源 (編譯自動嵌入)
- `icon/R2MS_Lite_CSV_CurrentQC.ico` — 程式圖示
- `exe/R2MS_Lite_CSV_CurrentQC.exe` — 編譯後執行檔 (雙擊執行)
- `build.bat` — 重新編譯腳本

## 使用方式

1. 雙擊 `R2MS_Lite_CSV_CurrentQC.exe`
2. 在檔案選擇對話框中選擇 CSV 檔案
3. 程式自動分析並在同目錄產生同名 `.html` 報告與同名 `.md` 摘要

## 輸出

| 檔案 | 內容 |
| --- | --- |
| `*.html` | 完整報告：64 通道逐列結果 + 運行紀錄 |
| `*.md` | 摘要：程式碼區塊內以逗號分隔的完整表（32 列：左半奇數 BOARD 01/03/05/07，右半偶數 BOARD 02/04/06/08） |

MD 表格格式：整張表包在 code fence 內、以逗號分隔；左右各一組相同欄位（BOARD, CH, AVG(MEAS)[A], AVG(PSU)[A], AVG(MEAS/PSU)[%], count），左半為奇數 BOARD、右半為偶數 BOARD，同一列的通道編號互相對應（如 CH01 對 CH09）；電壓 9 位小數，百分比欄為比值×100、固定 2 位小數並以空白靠右補齊（小數點對齊），資料不刪減。

計算方式：AVG(MEAS)、AVG(PSU)、AVG(MEAS/PSU) 使用同一批有效筆數（CH≠0 且 Rx≠0），count 即該筆數；因此 `AVG(MEAS)/AVG(PSU)×100` 與 `AVG(MEAS/PSU)[%]` 只在「逐筆比值平均」與「平均後相除」的差異上不同。

MD 檔頭會標示：來源檔名、產生時間、**程式版本**（例如 `R2MS_Lite_CSV_CurrentQC v20261030b`）、資料筆數、判定標準與 BOARD 對應。

## 版本沿革

| 版本 | 變更 |
| --- | --- |
| v20261030b | 版本字串更新（內容與 v20261030a 相同） |
| v20261030a | 新增 MD 摘要輸出：code fence + 逗號分隔，64 通道併成 32 列（左奇數 BOARD、右偶數 BOARD）；欄位改為 BOARD, CH, AVG(MEAS)[A], AVG(PSU)[A], AVG(MEAS/PSU)[%], count |
| v20261022a | 初版，輸出 HTML 報告 |

## 作者

HsiupoYeh — v20261030b
