# R2MS_Lite_CSV_CurrentQC

分析 R2MS_Lite CSV 檔案的通道電流 (CH01~CH64) 與 Rx 電流比較，產出 QC 報告 (HTML)。

## 結構

- `src/main.go` — 主程式原始碼
- `src/go.mod` — Go 模組定義
- `src/rsrc.syso` — 圖示資源 (編譯自動嵌入)
- `icon/R2MS_Lite_CSV_CurrentQC.ico` — 程式圖示
- `exe/R2MS_Lite_CSV_CurrentQC.exe` — 編譯後執行檔 (雙擊執行)
- `build.bat` — 重新編譯腳本

## 使用方式

1. 雙擊 `R2MS_Lite_CSV_CurrentQC.exe`
2. 在檔案選擇對話框中選擇 CSV 檔案
3. 程式自動分析並在同目錄產生同名 `.html` 報告

## 作者

HsiupoYeh — v20261022a
