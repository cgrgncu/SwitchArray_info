// **************************************************************************//
//   Name: R2MS_Lite_CSV_CurrentQC
//   Copyright:
//   Author: HsiupoYeh
//   Version: v20261022a
//   Description: 分析 CSV 檔案 (R2MS_Lite_v299) 的通道電流與 Rx 電流比較，
//                產出 QC 報告 (HTML)。
// ==========================================================================//
// 【重要：使用說明】
// 1. 雙擊執行檔，選擇要分析的 CSV 檔案。
// 2. 程式會自動篩選資料 (每 10 筆保留 3~8) 並計算各通道 AVG。
// 3. 結果輸出為同名 HTML 檔案。
// **************************************************************************//

package main

import (
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

// ---------- comdlg32 ----------
var (
	comdlg32                 = syscall.NewLazyDLL("comdlg32.dll")
	procGetOpenFileNameW     = comdlg32.NewProc("GetOpenFileNameW")
	procCommDlgExtendedError = comdlg32.NewProc("CommDlgExtendedError")
)

type OPENFILENAME struct {
	LStructSize       uint32
	HwndOwner         uintptr
	HInstance         uintptr
	LpstrFilter       *uint16
	LpstrCustomFilter *uint16
	NMaxCustFilter    uint32
	NFilterIndex      uint32
	LpstrFile         *uint16
	NMaxFile          uint32
	LpstrFileTitle    *uint16
	NMaxFileTitle     uint32
	LpstrInitialDir   *uint16
	LpstrTitle        *uint16
	Flags             uint32
	NFileOffset       uint16
	NFileExtension    uint16
	LpstrDefExt       *uint16
	LCustData         uintptr
	LpfnHook          uintptr
	LpTemplateName    *uint16
}

const (
	OFN_FILEMUSTEXIST = 0x00001000
	OFN_PATHMUSTEXIST = 0x00000800
)

func pickCSVFile() (string, bool, uint32) {
	buf := make([]uint16, 1024)
	filterStr := "CSV Files\x00*.csv\x00All Files\x00*.*\x00\x00"
	filter, _ := syscall.UTF16FromString(filterStr)
	if len(filter) == 0 || filter[len(filter)-1] != 0 {
		filter = append(filter, 0)
	}
	cwd, _ := os.Getwd()
	var initDir *uint16
	if cwd != "" {
		initDir = syscall.StringToUTF16Ptr(cwd)
	}
	ofn := OPENFILENAME{
		LStructSize:     uint32(unsafe.Sizeof(OPENFILENAME{})),
		LpstrFilter:     &filter[0],
		LpstrFile:       &buf[0],
		NMaxFile:        uint32(len(buf)),
		LpstrInitialDir: initDir,
		Flags:           OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
		LpstrDefExt:     syscall.StringToUTF16Ptr("csv"),
		LpstrTitle:      syscall.StringToUTF16Ptr("選擇 CSV 檔案"),
	}
	ret, _, _ := procGetOpenFileNameW.Call(uintptr(unsafe.Pointer(&ofn)))
	if ret == 0 {
		errCode, _, _ := procCommDlgExtendedError.Call()
		return "", false, uint32(errCode)
	}
	return syscall.UTF16ToString(buf), true, 0
}

func splitCSVLine(line string) []string {
	return strings.Split(strings.TrimRight(line, "\r"), ",")
}

func htmlEscape(s string) string {
	s = strings.ReplaceAll(s, "&", "&amp;")
	s = strings.ReplaceAll(s, "<", "&lt;")
	s = strings.ReplaceAll(s, ">", "&gt;")
	return s
}

func htmlPathFromCSV(csvPath string) string {
	// replace .csv extension with .html
	lower := strings.ToLower(csvPath)
	if strings.HasSuffix(lower, ".csv") {
		return csvPath[:len(csvPath)-4] + ".html"
	}
	return csvPath + ".html"
}

func main() {
	fmt.Println("**************************************************************************")
	fmt.Println("  Name: R2MS_Lite_CSV_CurrentQC")
	fmt.Println("  Author: HsiupoYeh")
	fmt.Println("  Version: v20261022a")
	fmt.Println("  Description: 分析 CSV 檔案 (R2MS_Lite_v299) 的通道電流與 Rx 電流比較。")
	fmt.Println("               產出 QC 報告 (HTML)。")
	fmt.Println("**************************************************************************")
	fmt.Println()

	var path string
	if len(os.Args) > 1 {
		path = os.Args[1]
	} else {
		p, ok, errCode := pickCSVFile()
		if !ok {
			fmt.Println("未選擇檔案，程式結束。")
			if errCode != 0 {
				fmt.Printf("檔案對話框錯誤碼: 0x%X\n", errCode)
			}
			fmt.Println("按 Enter 鍵結束...")
			fmt.Scanln()
			return
		}
		path = p
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		fmt.Println("無法開啟檔案:", err)
		fmt.Println("按 Enter 鍵結束...")
		fmt.Scanln()
		return
	}
	text := string(raw)
	lines := strings.Split(text, "\n")
	for len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) == "" {
		lines = lines[:len(lines)-1]
	}
	if len(lines) == 0 {
		fmt.Println("檔案為空")
		fmt.Println("按 Enter 鍵結束...")
		fmt.Scanln()
		return
	}

	// Accumulate all output into a builder (also include startup banner for HTML log)
	var out strings.Builder
	out.WriteString("**************************************************************************\n")
	out.WriteString("  Name: R2MS_Lite_CSV_CurrentQC\n")
	out.WriteString("  Author: HsiupoYeh\n")
	out.WriteString("  Version: v20261022a\n")
	out.WriteString("  Description: 分析 CSV 檔案 (R2MS_Lite_v299) 的通道電流與 Rx 電流比較。\n")
	out.WriteString("               產出 QC 報告 (HTML)。\n")
	out.WriteString("**************************************************************************\n\n")
	w := func(s string) { out.WriteString(s) }
	wf := func(format string, a ...interface{}) { fmt.Fprintf(&out, format, a...) }

	wf("===== 正在分析: %s =====\n", filepath.Base(path))
	header := splitCSVLine(lines[0])
	rows := lines[1:]

	wf("原本資料數量: %d 筆\n", len(rows))

	kept := [][]string{}
	for i, r := range rows {
		pos := i % 10
		if pos >= 2 && pos <= 7 {
			kept = append(kept, splitCSVLine(r))
		}
	}
	wf("篩選後資料數量: %d 筆 (每 10 筆保留 3~8)\n", len(kept))

	chIdx := make([]int, 64)
	for c := range chIdx {
		chIdx[c] = -1
	}
	rxIdx := -1
	for i, h := range header {
		name := strings.TrimSpace(h)
		for c := 0; c < 64; c++ {
			if name == fmt.Sprintf("CH%02d_Current[A]", c+1) {
				chIdx[c] = i
			}
		}
		if name == "Rx_Current[A]" {
			rxIdx = i
		}
	}

	chVals := make([][]float64, 64)
	for c := range chVals {
		chVals[c] = []float64{}
	}
	rxVals := []float64{}
	for _, rec := range kept {
		rxv := 0.0
		hasRx := false
		if rxIdx >= 0 && rxIdx < len(rec) {
			if fv, perr := strconv.ParseFloat(strings.TrimSpace(rec[rxIdx]), 64); perr == nil {
				rxv = fv
				hasRx = true
			}
		}
		if hasRx {
			rxVals = append(rxVals, rxv)
		} else {
			rxVals = append(rxVals, 0)
		}
		for c := 0; c < 64; c++ {
			ci := chIdx[c]
			cv := 0.0
			hasCv := false
			if ci >= 0 && ci < len(rec) {
				if fv, perr := strconv.ParseFloat(strings.TrimSpace(rec[ci]), 64); perr == nil {
					cv = fv
					hasCv = true
				}
			}
			if hasCv {
				chVals[c] = append(chVals[c], cv)
			} else {
				chVals[c] = append(chVals[c], 0)
			}
		}
	}

	channelAvg := make([]float64, 64)
	channelAvgCH := make([]float64, 64)
	channelAvgRx := make([]float64, 64)
	channelCnt := make([]int, 64)
	hasAvg := make([]bool, 64)
	for c := 0; c < 64; c++ {
		chName := fmt.Sprintf("CH%02d", c+1)
		wf("\n===== %s 與 Rx_Current[A] 逐筆比較 =====\n", chName)
		cv := chVals[c]
		n := len(cv)
		if len(rxVals) < n {
			n = len(rxVals)
		}
		sumRatio := 0.0
		cntRatio := 0
		sumCH := 0.0
		sumRx := 0.0
		for i := 0; i < n; i++ {
			ch := math.Abs(cv[i])
			rx := rxVals[i]
			sumCH += ch
			sumRx += rx
			if ch == 0 {
				continue
			}
			if rx == 0 {
				wf("%s / Rx = %.9f / %.9f = 除以零 (N/A)\n", chName, ch, rx)
			} else {
				ratio := ch / rx
				wf("%s / Rx = %.9f / %.9f = %.9f\n", chName, ch, rx, ratio)
				sumRatio += ratio
				cntRatio++
			}
		}
		avgCH := 0.0
		avgRx := 0.0
		if n > 0 {
			avgCH = sumCH / float64(n)
			avgRx = sumRx / float64(n)
		}
		channelAvgCH[c] = avgCH
		channelAvgRx[c] = avgRx
		if cntRatio > 0 {
			avg := sumRatio / float64(cntRatio)
			channelAvg[c] = avg
			channelCnt[c] = cntRatio
			hasAvg[c] = true
			wf("AVG(%s) = %.9f | AVG(Rx) = %.9f | AVG(%s/Rx) = %.9f  (共 %d 筆)\n", chName, avgCH, avgRx, chName, avg, cntRatio)
		} else {
			wf("AVG(%s) = %.9f | AVG(Rx) = %.9f | AVG(%s/Rx) = N/A  (無有效資料)\n", chName, avgCH, avgRx, chName)
		}
	}

	w("\n===== 統計結果 =====\n")
	for c := 0; c < 64; c++ {
		chName := fmt.Sprintf("CH%02d", c+1)
		if hasAvg[c] {
			wf("AVG(%s) = %.9f | AVG(Rx) = %.9f | AVG(%s/Rx) = %.9f  (共 %d 筆)\n", chName, channelAvgCH[c], channelAvgRx[c], chName, channelAvg[c], channelCnt[c])
		} else {
			wf("AVG(%s) = %.9f | AVG(Rx) = %.9f | AVG(%s/Rx) = N/A  (無有效資料)\n", chName, channelAvgCH[c], channelAvgRx[c], chName)
		}
	}
	w("\n分析完成。\n")

	logText := out.String()

	// Print to console
	fmt.Print(logText)

	// Write HTML file (filename based on CSV name)
	htmlPath := htmlPathFromCSV(path)
	// Build results table rows
	// Determine if any channel in a board is red (>1.15)
	boardHasRed := make([]bool, 8)
	for c := 0; c < 64; c++ {
		if hasAvg[c] && channelAvg[c] > 1.15 {
			boardHasRed[c/8] = true
		}
	}

	var rowsHTML strings.Builder
	for c := 0; c < 64; c++ {
		chName := fmt.Sprintf("CH%02d", c+1)
		board := fmt.Sprintf("%02d", (c/8)+1)
		boardColor := ""
		if boardHasRed[c/8] {
			boardColor = " style=\"color:#ef4444;font-weight:700;\""
		}
		if hasAvg[c] {
			avgRxRatio := channelAvg[c]
			color := ""
			if avgRxRatio > 1.15 {
				color = " style=\"color:#ef4444;font-weight:700;\""
			}
			rowsHTML.WriteString(fmt.Sprintf("<tr><td%s>%s</td><td>%s</td><td>%.9f</td><td>%.9f</td><td%s>%.9f</td><td>%d</td></tr>\n", boardColor, board, chName, channelAvgCH[c], channelAvgRx[c], color, avgRxRatio, channelCnt[c]))
		} else {
			rowsHTML.WriteString(fmt.Sprintf("<tr><td%s>%s</td><td>%s</td><td>%.9f</td><td>%.9f</td><td>N/A</td><td>0</td></tr>\n", boardColor, board, chName, channelAvgCH[c], channelAvgRx[c]))
		}
	}

	html := "<!DOCTYPE html>\n<html lang=\"zh-Hant\">\n<head>\n<meta charset=\"utf-8\">\n"
	html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
	html += "<title>R2MS_Lite_CSV_CurrentQC CSV 分析結果 - " + htmlEscape(filepath.Base(path)) + "</title>\n"
	html += "<style>\n"
	html += "*{box-sizing:border-box;}\n"
	html += "body{font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:0;}\n"
	html += ".app{max-width:900px;margin:0 auto;padding:24px;}\n"
	html += "h1{color:#38bdf8;margin:0 0 4px;font-size:22px;}\n"
	html += ".sub{color:#94a3b8;font-size:13px;margin-bottom:20px;}\n"
	html += ".tabs{display:flex;gap:8px;margin-bottom:16px;}\n"
	html += ".tab{flex:1;padding:12px;border:none;border-radius:10px;background:#1e293b;color:#cbd5e1;font-size:15px;cursor:pointer;transition:all .2s;}\n"
	html += ".tab.active{background:#38bdf8;color:#0f172a;font-weight:600;}\n"
	html += ".panel{display:none;background:#1e293b;border-radius:12px;padding:16px;box-shadow:0 4px 20px rgba(0,0,0,.3);}\n"
	html += ".panel.active{display:block;}\n"
	html += ".stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px;}\n"
	html += ".card{background:#0f172a;border-radius:10px;padding:14px;}\n"
	html += ".card .label{color:#94a3b8;font-size:12px;}\n"
	html += ".card .val{color:#38bdf8;font-size:20px;font-weight:700;margin-top:4px;}\n"
	html += "table{width:100%;border-collapse:collapse;font-size:14px;}\n"
	html += "th,td{padding:10px 12px;text-align:left;border-bottom:1px solid #334155;}\n"
	html += "th{color:#38bdf8;font-weight:600;position:sticky;top:0;background:#1e293b;}\n"
	html += "tr:hover{background:#0f172a;}\n"
	html += ".tablewrap{max-height:60vh;overflow:auto;border-radius:8px;}\n"
	html += "pre{white-space:pre-wrap;word-wrap:break-word;background:#0f172a;padding:16px;border-radius:8px;font-size:12px;line-height:1.5;max-height:70vh;overflow:auto;}\n"
	html += "</style>\n</head>\n<body>\n<div class=\"app\">\n"
	html += "<h1>R2MS_Lite_CSV_CurrentQC CSV 分析結果</h1>\n"
	html += "<p class=\"sub\">來源檔案: " + htmlEscape(filepath.Base(path)) + "</p>\n"
	html += "<p class=\"sub\">Program: R2MS_Lite_CSV_CurrentQC v20261022a &nbsp;|&nbsp; Author: HsiupoYeh</p>\n"
	html += "<div class=\"tabs\">\n"
	html += "<button class=\"tab active\" onclick=\"showTab('result')\">結果</button>\n"
	html += "<button class=\"tab\" onclick=\"showTab('log')\">運行紀錄</button>\n"
	html += "</div>\n"
	// result panel
	html += "<div id=\"result\" class=\"panel active\">\n"
	html += "<div class=\"stats\">\n"
	html += fmt.Sprintf("<div class=\"card\"><div class=\"label\">原始資料</div><div class=\"val\">%d 筆</div></div>\n", len(rows))
	html += fmt.Sprintf("<div class=\"card\"><div class=\"label\">篩選後資料</div><div class=\"val\">%d 筆</div></div>\n", len(kept))
	html += fmt.Sprintf("<div class=\"card\"><div class=\"label\">通道數</div><div class=\"val\">64</div></div>\n")
	html += "</div>\n"
	html += "<div class=\"tablewrap\"><table>\n"
	html += "<thead><tr><th>BOARD</th><th>通道</th><th>AVG(CH)</th><th>AVG(Rx)</th><th>AVG(CH/Rx)</th><th>有效筆數</th></tr></thead>\n"
	html += "<tbody>\n" + rowsHTML.String() + "</tbody>\n"
	html += "</table></div>\n"
	html += "</div>\n"
	// log panel
	html += "<div id=\"log\" class=\"panel\">\n"
	html += "<pre>" + htmlEscape(logText) + "</pre>\n"
	html += "</div>\n"
	html += "<script>\n"
	html += "function showTab(t){\n"
	html += "document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));\n"
	html += "document.querySelectorAll('.tab').forEach(b=>b.classList.remove('active'));\n"
	html += "document.getElementById(t).classList.add('active');\n"
	html += "event.target.classList.add('active');\n"
	html += "}\n"
	html += "</script>\n"
	html += "</div>\n</body>\n</html>\n"

	if err := os.WriteFile(htmlPath, []byte(html), 0644); err != nil {
		fmt.Println("HTML 寫入失敗:", err)
	} else {
		fmt.Println("\nHTML 已輸出: " + htmlPath)
	}

	fmt.Println("按 Enter 鍵結束程式...")
	fmt.Scanln()
}
