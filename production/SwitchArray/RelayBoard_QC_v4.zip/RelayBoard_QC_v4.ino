#include <WiFi.h>
#include <WebServer.h>

// ==========================================
// 1. 硬體與網路參數設定
// ==========================================
constexpr char* AP_SSID = "ESP32_LED_Controller";
constexpr char* AP_PASSWORD = "12345678";

WebServer server(80);

// 硬體架構腳位定義
constexpr int SRCLR_PIN = 14;  
constexpr int SER_PIN = 21;      
constexpr int SRCLK_PIN = 23;  

constexpr int RCLK_PINS[4] = {13, 12, 22, 26}; // 對應 1~4 排的鎖存腳
constexpr int OE_PIN_V_enable = 25;  

// REF 繼電器控制腳位定義
constexpr int REF_RELAY_PIN = 18; // 可根據實際硬體線路調整 GPIO 腳位

// 核心資料結構：二維陣列 [8片][每片4排]
uint8_t ledData[8][4] = {
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00},
  {0x00, 0x00, 0x00, 0x00}
};

// ==========================================
// 2. 共用核心控制邏輯
// ==========================================
void executeControl(int plate, int row, int led, int state) {
  int pIdx = plate - 1;
  int rIdx = row - 1;
  int bitPos = led - 1;
  
  if (state == 1) ledData[pIdx][rIdx] |= (1 << bitPos);
  else ledData[pIdx][rIdx] &= ~(1 << bitPos);
  
  for (int r = 0; r < 4; r++) {
    for (int p = 7; p >= 0; p--) {
      shiftOut(SER_PIN, SRCLK_PIN, MSBFIRST, ledData[p][r]);
    }
    digitalWrite(RCLK_PINS[r], HIGH);
    delayMicroseconds(2);
    digitalWrite(RCLK_PINS[r], LOW);
  }
}

void executeRowControl(int plate, int row, int state) {
  ledData[plate - 1][row - 1] = (state == 1) ? 0xFF : 0x00;
  
  for (int r = 0; r < 4; r++) {
    for (int p = 7; p >= 0; p--) {
      shiftOut(SER_PIN, SRCLK_PIN, MSBFIRST, ledData[p][r]);
    }
    digitalWrite(RCLK_PINS[r], HIGH);
    delayMicroseconds(2);
    digitalWrite(RCLK_PINS[r], LOW);
  }
}

void executeGlobal(int state) {
  uint8_t fillValue = (state == 1) ? 0xFF : 0x00;
  for (int p = 0; p < 8; p++) {
    for (int r = 0; r < 4; r++) {
      ledData[p][r] = fillValue;
    }
  }
  
  for (int r = 0; r < 4; r++) {
    for (int p = 7; p >= 0; p--) {
      shiftOut(SER_PIN, SRCLK_PIN, MSBFIRST, ledData[p][r]);
    }
    digitalWrite(RCLK_PINS[r], HIGH);
    delayMicroseconds(2);
    digitalWrite(RCLK_PINS[r], LOW);
  }
}

void executeRefControl(int state) {
  digitalWrite(REF_RELAY_PIN, (state == 1) ? HIGH : LOW);
}

// ==========================================
// 3. 網頁前端原始碼 (HTML / CSS / JS)
// ==========================================
const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ESP32 LED 行動控制面板</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; text-align: center; background-color: #f4f4f9; color: #333; margin: 0; padding: 15px; -webkit-tap-highlight-color: transparent; }
        h1 { color: #444; font-size: 24px; margin-top: 10px; }
        .plate-title { background: #34495e; color: white; padding: 8px; font-size: 16px; border-radius: 6px; margin: 20px auto 10px auto; max-width: 950px; font-weight: bold; }
        .global-controls { margin-bottom: 20px; display: flex; justify-content: center; gap: 10px; }
        .btn { flex: 1; max-width: 180px; padding: 14px 10px; font-size: 15px; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; transition: 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .btn-all-on { background-color: #2ecc71; color: white; }
        .btn-all-off { background-color: #e74c3c; color: white; }
        .btn-row-on { background-color: #3498db; color: white; padding: 8px; font-size: 13px; border-radius: 5px; border: none; cursor: pointer; flex: 1; }
        .btn-row-off { background-color: #95a5a6; color: white; padding: 8px; font-size: 13px; border-radius: 5px; border: none; cursor: pointer; flex: 1; }
        .btn:active, .btn-row-on:active, .btn-row-off:active { opacity: 0.8; transform: scale(0.98); }
        
        .matrix-container { display: flex; flex-direction: column; gap: 15px; max-width: 950px; margin: 0 auto 20px auto; }
        .row-container { display: flex; flex-direction: column; background: white; padding: 15px; border-radius: 12px; box-shadow: 0 3px 6px rgba(0,0,0,0.05); box-sizing: border-box; width: 100%; }
        .row-header { display: flex; align-items: center; justify-content: space-between; width: 100%; border-bottom: 1px solid #eee; padding-bottom: 8px; margin-bottom: 10px; }
        .row-label { font-weight: bold; color: #2c3e50; font-size: 15px; text-align: left; }
        
        .btn-note { background-color: #f39c12; color: white; border: none; border-radius: 4px; padding: 5px 10px; font-size: 12px; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .note-box { display: none; background-color: #fffde7; border-left: 4px solid #f1c40f; padding: 10px; margin-bottom: 12px; text-align: left; font-size: 13px; line-height: 1.5; color: #7f8c8d; border-radius: 0 6px 6px 0; }
        .note-box strong { color: #d35400; }

        .row-body { display: flex; flex-direction: row; align-items: center; width: 100%; }
        .row-ops { display: flex; flex-direction: column; gap: 5px; width: 80px; margin-right: 15px; }
        
        .led-grid { display: flex; flex-direction: row-reverse; gap: 8px; flex-grow: 1; justify-content: flex-end; }
        .led-btn { width: 62px; height: 44px; border: 2px solid #bdc3c7; border-radius: 22px; background-color: #ecf0f1; cursor: pointer; font-size: 12px; font-weight: bold; color: #7f8c8d; transition: all 0.1s; display: flex; align-items: center; justify-content: center; white-space: nowrap; box-shadow: inset 0 -2px 0 rgba(0,0,0,0.05); }
        .led-btn.active { background-color: #f1c40f; border-color: #f39c12; color: #fff; box-shadow: 0 0 12px #f1c40f; }
        .led-btn.pending { opacity: 0.3; cursor: wait; pointer-events: none; }

        .control-bar-8 { max-width: 950px; margin: 30px auto 10px auto; background: #e8f8f5; padding: 15px; border-radius: 12px; border: 2px dashed #16a085; }
        .control-bar-title { font-size: 15px; font-weight: bold; color: #16a085; margin-bottom: 8px; }
        .btn-toggle-8 { background-color: #16a085; color: white; padding: 12px 24px; font-size: 14px; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; }

        /* REF 繼電器控制面板樣式（加入 active 視覺效果） */
        .control-bar-ref { max-width: 950px; margin: 15px auto 10px auto; background: #fef9e7; padding: 15px; border-radius: 12px; border: 2px dashed #f39c12; }
        .control-bar-ref-title { font-size: 15px; font-weight: bold; color: #d35400; margin-bottom: 8px; }
        .ref-controls { display: flex; justify-content: center; gap: 10px; }
        .btn-ref-on { background-color: #7f8c8d; color: white; }
        .btn-ref-off { background-color: #7f8c8d; color: white; }
        .btn-ref-on.active { background-color: #e67e22 !important; box-shadow: 0 0 12px #e67e22; }
        .btn-ref-off.active { background-color: #95a5a6 !important; opacity: 0.9; }

        @media (max-width: 768px) {
            .row-body { flex-direction: column; align-items: stretch; gap: 10px; }
            .row-ops { flex-direction: row; width: 100%; margin-right: 0; gap: 8px; }
            .led-grid { flex-direction: row-reverse; flex-wrap: wrap-reverse; justify-content: center; gap: 10px 6px; }
            .led-btn { width: calc(25% - 6px); height: 46px; font-size: 11px; }
        }
    </style>
</head>
<body>

    <h1>ESP32 多晶片串聯 LED 控制面板</h1>
    
    <div class="global-controls">
        <button class="btn btn-all-on" onclick="controlGlobal(1)">ALL ON</button>
        <button class="btn btn-all-off" onclick="controlGlobal(0)">ALL OFF</button>
    </div>

    <div id="panels-container"></div>

    <div class="control-bar-8">
        <div class="control-bar-title">遙控硬體功能：動態切換 8 片串聯配置</div>
        <button class="btn-toggle-8" id="mode-btn" onclick="toggleEightPlates()">開啟 8 片串聯控制模式</button>
    </div>

    <!-- 網頁前端 REF 繼電器控制區塊 -->
    <div class="control-bar-ref">
        <div class="control-bar-ref-title">硬體擴充功能：REF 繼電器控制</div>
        <div class="ref-controls">
            <button class="btn btn-ref-on" id="ref-on-btn" onclick="controlRef(1)">REF ON</button>
            <button class="btn btn-ref-off" id="ref-off-btn" onclick="controlRef(0)">REF OFF</button>
        </div>
    </div>

    <script>
        const panelsContainer = document.getElementById('panels-container');
        let maxPlates = 1;

        const rowTemplates = {
            1: { name: "第 1 排(大顆)", note: "<strong>⚠️ 除錯筆記：</strong><br>1. 粗橙(PSU+) 與 頻道(CH1~8) 之電阻為 <strong>10~12 歐姆</strong>。<br>2. 粗橙(PSU+) 與 粗灰(PSU-) <strong>無法導通</strong>。" },
            2: { name: "第 2 排(大顆)", note: "<strong>⚠️ 除錯筆記：</strong><br>1. 粗灰(PSU-) 與 頻道(CH1~8) 之電阻為 <strong>10~12 歐姆</strong>。<br>2. 粗橙(PSU+) 與 粗灰(PSU-) <strong>無法導通</strong>。" },
            3: { name: "第 3 排(小顆)", note: "<strong>⚠️ 除錯筆記：</strong><br>1. 粗黑(DMM-) 與 頻道(CH1~8) 之電阻為 <strong>36~40 歐姆</strong>。<br>2. 粗黑(DMM-) 與 粗紅(DMM+) <strong>無法導通</strong>。" },
            4: { name: "第 4 排(小顆)", note: "<strong>⚠️ 除錯筆記：</strong><br>1. 粗紅(DMM+) 與 頻道(CH1~8) 之電阻為 <strong>25~30 歐姆</strong>。<br>2. 粗黑(DMM-) 與 粗紅(DMM+) <strong>無法導通</strong>。" }
        };

        function renderUI() {
            panelsContainer.innerHTML = "";
            for (let plate = 1; plate <= maxPlates; plate++) {
                const plateHeader = document.createElement('div');
                plateHeader.className = 'plate-title';
                plateHeader.innerText = `晶片模組 [第 ${plate} 片]`;
                panelsContainer.appendChild(plateHeader);

                const matrixContainer = document.createElement('div');
                matrixContainer.className = 'matrix-container';

                for (let row = 1; row <= 4; row++) {
                    const config = rowTemplates[row];
                    const rowDiv = document.createElement('div');
                    rowDiv.className = 'row-container';
                    
                    const headerDiv = document.createElement('div');
                    headerDiv.className = 'row-header';
                    headerDiv.innerHTML = `
                        <div class="row-label">[片 ${plate}] - ${config.name}</div>
                        <button class="btn-note" onclick="toggleNote(${plate}, ${row})">📝 偵錯筆記</button>
                    `;
                    rowDiv.appendChild(headerDiv);

                    const noteDiv = document.createElement('div');
                    noteDiv.className = 'note-box';
                    noteDiv.id = `note-${plate}-${row}`;
                    noteDiv.innerHTML = config.note;
                    rowDiv.appendChild(noteDiv);

                    const bodyDiv = document.createElement('div');
                    bodyDiv.className = 'row-body';

                    const rowOps = document.createElement('div');
                    rowOps.className = 'row-ops';
                    rowOps.innerHTML = `
                        <button class="btn-row-on" onclick="controlRow(${plate}, ${row}, 1)">整排亮</button>
                        <button class="btn-row-off" onclick="controlRow(${plate}, ${row}, 0)">整排滅</button>
                    `;
                    bodyDiv.appendChild(rowOps);
                    
                    const grid = document.createElement('div');
                    grid.className = 'led-grid';
                    
                    for (let led = 1; led <= 8; led++) {
                        const btn = document.createElement('button');
                        btn.className = 'led-btn';
                        btn.id = `led-${plate}-${row}-${led}`;
                        
                        let uNumber = (maxPlates === 1) ? ((led - 1) * 4 + row) : ((led - 1) * 4 + row + ((plate - 1) * 32));
                        btn.innerText = `${led}(U${uNumber})`;
                        
                        btn.onclick = () => toggleLed(plate, row, led, btn);
                        grid.appendChild(btn);
                    }
                    
                    bodyDiv.appendChild(grid);
                    rowDiv.appendChild(bodyDiv);
                    matrixContainer.appendChild(rowDiv);
                }
                panelsContainer.appendChild(matrixContainer);
            }
        }

        function toggleEightPlates() {
            if (maxPlates === 1) {
                maxPlates = 8;
                document.getElementById('mode-btn').innerText = "切回 1 片獨立模式";
                document.getElementById('mode-btn').style.backgroundColor = "#c0392b";
            } else {
                maxPlates = 1;
                document.getElementById('mode-btn').innerText = "開啟 8 片串聯控制模式";
                document.getElementById('mode-btn').style.backgroundColor = "#16a085";
            }
            renderUI();
            syncStates();
        }

        function toggleNote(plate, row) {
            const noteBox = document.getElementById(`note-${plate}-${row}`);
            noteBox.style.display = (noteBox.style.display === "block") ? "none" : "block";
        }

        // 同步所有 LED 與 REF 繼電器狀態
        function syncStates() {
            fetch('/getState')
                .then(res => { if (res.ok) return res.json(); throw new Error(); })
                .then(data => {
                    // 1. 同步 LED 矩陣狀態
                    let matrix = data.matrix;
                    for (let p = 1; p <= maxPlates; p++) {
                        for (let r = 1; r <= 4; r++) {
                            let rowByte = matrix[p-1][r-1];
                            let l = 1;
                            for (; l <= 8; l++) {
                                let isActive = (rowByte >> (l - 1)) & 1;
                                const btn = document.getElementById(`led-${p}-${r}-${l}`);
                                if (btn) {
                                    if (isActive) btn.classList.add('active');
                                    else btn.classList.remove('active');
                                }
                            }
                        }
                    }

                    // 2. 同步 REF 繼電器按鈕狀態顯示
                    updateRefUI(data.refState);
                })
                .catch(err => console.log("同步失敗"));
        }

        renderUI();
        window.addEventListener('DOMContentLoaded', () => { syncStates(); });

        function toggleLed(plate, row, led, btn) {
            const newState = btn.classList.contains('active') ? 0 : 1;
            btn.classList.add('pending');
            
            fetch(`/control?plate=${plate}&row=${row}&led=${led}&state=${newState}`)
                .then(res => { if (res.ok) return res.text(); throw new Error(); })
                .then(() => {
                    btn.classList.remove('pending');
                    if(newState === 1) btn.classList.add('active');
                    else btn.classList.remove('active');
                })
                .catch(() => {
                    btn.classList.remove('pending');
                    alert("溝通失敗！");
                });
        }

        function controlRow(plate, row, state) {
            const rowBtns = [];
            for(let l=1; l<=8; l++) {
                const b = document.getElementById(`led-${plate}-${row}-${l}`);
                if(b) { b.classList.add('pending'); rowBtns.push(b); }
            }

            fetch(`/rowControl?plate=${plate}&row=${row}&state=${state}`)
                .then(res => { if (res.ok) return res.text(); throw new Error(); })
                .then(() => {
                    rowBtns.forEach(btn => {
                        btn.classList.remove('pending');
                        if (state === 1) btn.classList.add('active');
                        else btn.classList.remove('active');
                    });
                })
                .catch(() => {
                    rowBtns.forEach(btn => btn.classList.remove('pending'));
                    alert("溝通失敗！");
                });
        }

        function controlGlobal(state) {
            const allBtns = document.querySelectorAll('.led-btn');
            allBtns.forEach(btn => btn.classList.add('pending'));

            fetch(`/global?state=${state}`)
                .then(res => { if (res.ok) return res.text(); throw new Error(); })
                .then(() => {
                    allBtns.forEach(btn => {
                        btn.classList.remove('pending');
                        if (state === 1) btn.classList.add('active');
                        else btn.classList.remove('active');
                    });
                })
                .catch(() => {
                    allBtns.forEach(btn => btn.classList.remove('pending'));
                    alert("溝通失敗！");
                });
        }

        function updateRefUI(state) {
            const refOnBtn = document.getElementById('ref-on-btn');
            const refOffBtn = document.getElementById('ref-off-btn');
            if (state === 1) {
                refOnBtn.classList.add('active');
                refOffBtn.classList.remove('active');
            } else {
                refOnBtn.classList.remove('active');
                refOffBtn.classList.add('active');
            }
        }

        function controlRef(state) {
            const refOnBtn = document.getElementById('ref-on-btn');
            const refOffBtn = document.getElementById('ref-off-btn');
            refOnBtn.classList.add('pending');
            refOffBtn.classList.add('pending');

            fetch(`/refControl?state=${state}`)
                .then(res => { if (res.ok) return res.text(); throw new Error(); })
                .then(() => {
                    refOnBtn.classList.remove('pending');
                    refOffBtn.classList.remove('pending');
                    updateRefUI(state);
                })
                .catch(() => {
                    refOnBtn.classList.remove('pending');
                    refOffBtn.classList.remove('pending');
                    alert("REF 繼電器溝通失敗！");
                });
        }
    </script>
</body>
</html>
)rawliteral";

// ==========================================
// 4. WebServer 路由實作
// ==========================================
void handleRoot() {
  server.send(200, "text/html", INDEX_HTML);
}

// 修改：將 /getState 擴充為同時回傳 LED 陣列與 REF 繼電器狀態的 JSON
void handleGetState() {
  String json = "{";
  
  // 1. LED 矩陣狀態
  json += "\"matrix\":[";
  for (int p = 0; p < 8; p++) {
    json += "[";
    for (int r = 0; r < 4; r++) {
      json += String(ledData[p][r]);
      if (r < 3) json += ",";
    }
    json += "]";
    if (p < 7) json += ",";
  }
  json += "],";

  // 2. REF 繼電器狀態 (讀取實際 GPIO 輸出狀態)
  int refState = digitalRead(REF_RELAY_PIN) == HIGH ? 1 : 0;
  json += "\"refState\":" + String(refState);
  
  json += "}";
  server.send(200, "application/json", json);
}

void handleControl() {
  if (server.hasArg("plate") && server.hasArg("row") && server.hasArg("led") && server.hasArg("state")) {
    int plate = server.arg("plate").toInt();
    int row = server.arg("row").toInt();
    int led = server.arg("led").toInt();
    int state = server.arg("state").toInt();
    
    if (plate >= 1 && plate <= 8 && row >= 1 && row <= 4 && led >= 1 && led <= 8) {
      executeControl(plate, row, led, state);
      Serial.printf("[網路 API] control -> 片:%d 排:%d 燈:%d 狀態:%d\n", plate, row, led, state);
      server.send(200, "text/plain", "OK");
      return;
    }
  }
  server.send(400, "text/plain", "Bad Request");
}

void handleRowControl() {
  if (server.hasArg("plate") && server.hasArg("row") && server.hasArg("state")) {
    int plate = server.arg("plate").toInt();
    int row = server.arg("row").toInt();
    int state = server.arg("state").toInt();
    
    if (plate >= 1 && plate <= 8 && row >= 1 && row <= 4) {
      executeRowControl(plate, row, state);
      Serial.printf("[網路 API] rowControl -> 片:%d 排:%d 狀態:%d\n", plate, row, state);
      server.send(200, "text/plain", "OK");
      return;
    }
  }
  server.send(400, "text/plain", "Bad Request");
}

void handleGlobal() {
  if (server.hasArg("state")) {
    int state = server.arg("state").toInt();
    executeGlobal(state);
    Serial.printf("[網路 API] global -> 狀態:%d\n", state);
    server.send(200, "text/plain", "OK");
    return;
  }
  server.send(400, "text/plain", "Bad Request");
}

void handleRefControl() {
  if (server.hasArg("state")) {
    int state = server.arg("state").toInt();
    if (state == 0 || state == 1) {
      executeRefControl(state);
      Serial.printf("[網路 API] refControl -> 狀態:%d\n", state);
      server.send(200, "text/plain", "OK");
      return;
    }
  }
  server.send(400, "text/plain", "Bad Request");
}

void handleReboot() {
  server.send(200, "text/plain", "ESP32 is rebooting...");
  Serial.println("[系統] 收到遠端重開機指令，正在重新啟動...");
  Serial.flush();
  delay(100);
  ESP.restart();
}

// ==========================================
// 5. USB Serial 嚴格完整性與完整網址 URL 解析器
// ==========================================
int getQueryParam(String query, String key) {
  int idx = query.indexOf(key + "=");
  if (idx == -1) return -1;
  int start = idx + key.length() + 1;
  int end = query.indexOf('&', start);
  if (end == -1) end = query.length();
  return query.substring(start, end).toInt();
}

void handleSerialCommand() {
  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input.length() == 0) return;
    
    if (!input.startsWith("{") || !input.endsWith("}")) {
      Serial.println("[錯誤] 格式錯誤：非完整 JSON 封包");
      return;
    }

    int urlKeyIdx = input.indexOf("\"url\"");
    if (urlKeyIdx == -1) {
      Serial.println("[錯誤] 找不到 'url' 欄位");
      return;
    }

    int colonIdx = input.indexOf(':', urlKeyIdx);
    int firstQuote = input.indexOf('"', colonIdx);
    int secondQuote = input.indexOf('"', firstQuote + 1);

    if (colonIdx == -1 || firstQuote == -1 || secondQuote == -1) {
      Serial.println("[錯誤] 引號配對錯誤");
      return;
    }

    String url = input.substring(firstQuote + 1, secondQuote);
    if (url.length() == 0) {
      Serial.println("[錯誤] 'url' 欄位內容為空");
      return;
    }

    if (url.startsWith("http://") || url.startsWith("https://")) {
      int slash3 = url.indexOf('/', 8);
      if (slash3 != -1) {
        url = url.substring(slash3 + 1);
      } else {
        url = "";
      }
    }

    int qPos = url.indexOf('?');
    String endpoint = (qPos == -1) ? url : url.substring(0, qPos);
    String query = (qPos == -1) ? "" : url.substring(qPos + 1);

    if (endpoint == "control") {
      int plate = getQueryParam(query, "plate");
      int row = getQueryParam(query, "row");
      int led = getQueryParam(query, "led");
      int state = getQueryParam(query, "state");

      if (plate >= 1 && plate <= 8 && row >= 1 && row <= 4 && led >= 1 && led <= 8 && (state == 0 || state == 1)) {
        executeControl(plate, row, led, state);
        Serial.print("[JSON Serial] OK -> ");
        Serial.print("片:"); Serial.print(plate);
        Serial.print(" 排:"); Serial.print(row);
        Serial.print(" 燈:"); Serial.print(led);
        Serial.print(" 狀態:"); Serial.println(state);
      } else {
        Serial.println("[錯誤] API 參數數值超出有效範圍");
      }
    } 
    else if (endpoint == "rowControl") {
      int plate = getQueryParam(query, "plate");
      int row = getQueryParam(query, "row");
      int state = getQueryParam(query, "state");

      if (plate >= 1 && plate <= 8 && row >= 1 && row <= 4 && (state == 0 || state == 1)) {
        executeRowControl(plate, row, state);
        Serial.print("[JSON Serial] OK -> ");
        Serial.print("片:"); Serial.print(plate);
        Serial.print(" 排:"); Serial.print(row);
        Serial.print(" 狀態:"); Serial.println(state);
      } else {
        Serial.println("[錯誤] API 參數數值超出有效範圍");
      }
    } 
    else if (endpoint == "global") {
      int state = getQueryParam(query, "state");

      if (state == 0 || state == 1) {
        executeGlobal(state);
        Serial.print("[JSON Serial] OK -> 全域狀態:"); Serial.println(state);
      } else {
        Serial.println("[錯誤] state 參數必須為 0 或 1");
      }
    }
    else if (endpoint == "refControl") {
      int state = getQueryParam(query, "state");

      if (state == 0 || state == 1) {
        executeRefControl(state);
        Serial.print("[JSON Serial] OK -> REF 繼電器狀態:"); Serial.println(state);
      } else {
        Serial.println("[錯誤] state 參數必須為 0 或 1");
      }
    }
    else if (endpoint == "reboot" || endpoint == "reset") {
      Serial.println("[JSON Serial] 收到重開機指令，正在重新啟動...");
      Serial.flush();
      delay(100);
      ESP.restart();
    }
    else {
      Serial.println("[未知指令端點] 請檢查 url 內的路徑是否正確");
    }
  }
}

void printWifiStatus() {
  IPAddress myIP = WiFi.softAPIP();
  Serial.println("\n=============================================");
  Serial.printf(" 🌐 Wi-Fi 名稱 (SSID) : %s\n", AP_SSID);
  Serial.printf(" 🔑 連線密碼  (PASS) : %s\n", AP_PASSWORD);
  Serial.printf(" 🔗 控制網址         : http://%s\n", myIP.toString().c_str());
  Serial.println("---------------------------------------------");
  Serial.println(" 💡 1. 網頁 / API 控制範例說明：");
  Serial.printf("    1. 單燈控制: http://%s/control?plate=1&row=1&led=1&state=1\n", myIP.toString().c_str());
  Serial.printf("    2. 整排控制: http://%s/rowControl?plate=1&row=1&state=1\n", myIP.toString().c_str());
  Serial.printf("    3. 全域控制: http://%s/global?state=1\n", myIP.toString().c_str());
  Serial.printf("    4. REF繼電器: http://%s/refControl?state=1\n", myIP.toString().c_str());
  Serial.printf("    5. 取得狀態: http://%s/getState\n", myIP.toString().c_str());
  Serial.printf("    6. 遠端重啟: http://%s/reboot\n", myIP.toString().c_str());
  Serial.println("---------------------------------------------");
  Serial.println(" 💡 2. USB Serial 嚴格 JSON 格式控制範例：");
  Serial.printf("    {\"url\":\"http://%s/control?plate=1&row=1&led=1&state=1\",\"Notes\":\"單燈控制\"}\n", myIP.toString().c_str());
  Serial.printf("    {\"url\":\"http://%s/rowControl?plate=1&row=1&state=1\",\"Notes\":\"整排控制\"}\n", myIP.toString().c_str());
  Serial.printf("    {\"url\":\"http://%s/global?state=1\",\"Notes\":\"全域控制\"}\n", myIP.toString().c_str());
  Serial.printf("    {\"url\":\"http://%s/refControl?state=1\",\"Notes\":\"REF繼電器控制\"}\n", myIP.toString().c_str());
  Serial.printf("    {\"url\":\"http://%s/reboot\",\"Notes\":\"重開機\"}\n", myIP.toString().c_str());
  Serial.println(" ⚠️  [注意] url 內容中請勿直接包含雙引號 (\")，以免解析中斷！");
  Serial.println("=============================================");
}

// ==========================================
// 6. 系統進入點 (Setup & Loop)
// ==========================================
void setup() {
  Serial.begin(115200);
  
  pinMode(SRCLR_PIN, OUTPUT);
  pinMode(SER_PIN, OUTPUT);
  pinMode(SRCLK_PIN, OUTPUT);
  for (int i = 0; i < 4; i++) {
    pinMode(RCLK_PINS[i], OUTPUT);
    digitalWrite(RCLK_PINS[i], LOW);
  }
  pinMode(OE_PIN_V_enable, OUTPUT);
  digitalWrite(OE_PIN_V_enable, LOW);  

  pinMode(REF_RELAY_PIN, OUTPUT);
  digitalWrite(REF_RELAY_PIN, LOW);

  digitalWrite(SRCLR_PIN, LOW);        
  delay(10);                     
  digitalWrite(SRCLR_PIN, HIGH); 

  executeGlobal(0); 

  WiFi.softAP(AP_SSID, AP_PASSWORD);
  printWifiStatus();

  server.on("/", handleRoot);
  server.on("/getState", handleGetState); 
  server.on("/control", handleControl);     
  server.on("/rowControl", handleRowControl); 
  server.on("/global", handleGlobal);       
  server.on("/refControl", handleRefControl); 
  server.on("/reboot", handleReboot);       

  server.begin();
}

void loop() {
  server.handleClient();       
  handleSerialCommand();       
}