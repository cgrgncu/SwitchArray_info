clear;clc;close all
%-------------------------------------------------
% 6��v�ɫB�q report_month
%--
% curl�����
url_str='https://codis.cwa.gov.tw/api/station';
date_str='2024-06-01T00:00:00.000+08:00';
type_str='report_month';
stn_ID_str='466930';
stn_type_str='cwb';
start_str='2024-06-01T00:00:00';
end_str='2024-06-30T00:00:00';
%--
cmd_str=['curl.exe "-s" ', ...
    '-F "date=',date_str,'" ',...
    '-F "type=',type_str,'" ',...
    '-F "stn_ID=',stn_ID_str,'" ',...
    '-F "stn_type=',stn_type_str,'" ',...    
    '-F "start=',start_str,'" ',...  
    '-F "end=',end_str,'" ',...      
    url_str];
disp(cmd_str);

[status,cmdout]=system(cmd_str);
%disp(' ')
%--
% JSON�ѽX
report_month_06_struct=json_decode(cmdout);
%-------------------------------------------------
% ��z���
%--
% ���
DataDate_06_cell={report_month_06_struct.data.dts.DataDate}';
DataDate_06_char=char(DataDate_06_cell);
DataDate_06_datenum_array=datenum(DataDate_06_char,'yyyy-mm-ddTHH:MM:SS');
[sorted_DataDate_06_datenum_array,sorted_DataDate_06_datenum_array_index] = sort(DataDate_06_datenum_array);
DataDate_06_datenum_cell=num2cell(DataDate_06_datenum_array);
% [DataDate_06_cell,DataDate_06_datenum_cell]
%--
% ��ֿn�B�q
Precipitation_06_struct=[report_month_06_struct.data.dts.Precipitation];
Precipitation_06_Accumulation_cell={Precipitation_06_struct.Accumulation}';
Precipitation_06_Accumulation_array=[Precipitation_06_Accumulation_cell{:}]';
% �t�ȥ�0���N
Precipitation_06_Accumulation_array(Precipitation_06_Accumulation_array<0)=0;
Precipitation_06_Accumulation_cell=num2cell(Precipitation_06_Accumulation_array);
%--
% �饭�����
AirTemperature_06_struct=[report_month_06_struct.data.dts.AirTemperature];
AirTemperature_06_Mean_cell={AirTemperature_06_struct.Mean}';
%--
% �饭���a�Ŧb0CM
SoilTemperatureAt0cm_06_struct=[report_month_06_struct.data.dts.SoilTemperatureAt0cm];
SoilTemperatureAt0cm_06_Mean_cell={SoilTemperatureAt0cm_06_struct.Mean}';
%--
% �饭���a�Ŧb50CM
SoilTemperatureAt50cm_06_struct=[report_month_06_struct.data.dts.SoilTemperatureAt50cm];
SoilTemperatureAt50cm_06_Mean_cell={SoilTemperatureAt50cm_06_struct.Mean}';
%--
% �饭���a�Ŧb0CM
SoilTemperatureAt100cm_06_struct=[report_month_06_struct.data.dts.SoilTemperatureAt100cm];
SoilTemperatureAt100cm_06_Mean_cell={SoilTemperatureAt100cm_06_struct.Mean}';
%--
% �X��
all_06_cell=[DataDate_06_cell,DataDate_06_datenum_cell,Precipitation_06_Accumulation_cell,AirTemperature_06_Mean_cell,SoilTemperatureAt0cm_06_Mean_cell,SoilTemperatureAt50cm_06_Mean_cell,SoilTemperatureAt100cm_06_Mean_cell];
%--
% �Ƨ�
all_06_cell=all_06_cell(sorted_DataDate_06_datenum_array_index,:);
%--
all_06_cell_header={'���','datenum','��ֿn�B�q[mm]','�饭�����[�J]','�饭���a�Ŧb0CM[�J]','�饭���a�Ŧb50CM[�J]','�饭���a�Ŧb100CM[�J]'};
%-------------------------------------------------
%-------------------------------------------------
% 7��v�ɫB�q report_month
%--
% curl�����
url_str='https://codis.cwa.gov.tw/api/station';
date_str='2024-07-01T00:00:00.000+08:00';
type_str='report_month';
stn_ID_str='466930';
stn_type_str='cwb';
start_str='2024-07-01T00:00:00';
end_str='2024-07-31T00:00:00';
%--
cmd_str=['curl.exe "-s" ', ...
    '-F "date=',date_str,'" ',...
    '-F "type=',type_str,'" ',...
    '-F "stn_ID=',stn_ID_str,'" ',...
    '-F "stn_type=',stn_type_str,'" ',...    
    '-F "start=',start_str,'" ',...  
    '-F "end=',end_str,'" ',...      
    url_str];
%disp(cmd_str);
[status,cmdout]=system(cmd_str);
%disp(' ')
%--
% JSON�ѽX
report_month_07_struct=json_decode(cmdout);
%-------------------------------------------------
% ��z���
%--
% ���
DataDate_07_cell={report_month_07_struct.data.dts.DataDate}';
DataDate_07_char=char(DataDate_07_cell);
DataDate_07_datenum_array=datenum(DataDate_07_char,'yyyy-mm-ddTHH:MM:SS');
[sorted_DataDate_07_datenum_array,sorted_DataDate_07_datenum_array_index] = sort(DataDate_07_datenum_array);
DataDate_07_datenum_cell=num2cell(DataDate_07_datenum_array);
% [DataDate_07_cell,DataDate_07_datenum_cell]
%--
% ��ֿn�B�q
Precipitation_07_struct=[report_month_07_struct.data.dts.Precipitation];
Precipitation_07_Accumulation_cell={Precipitation_07_struct.Accumulation}';
Precipitation_07_Accumulation_array=[Precipitation_07_Accumulation_cell{:}]';
% �t�ȥ�0���N
Precipitation_07_Accumulation_array(Precipitation_07_Accumulation_array<0)=0;
Precipitation_07_Accumulation_cell=num2cell(Precipitation_07_Accumulation_array);
%--
% �饭�����
AirTemperature_07_struct=[report_month_07_struct.data.dts.AirTemperature];
AirTemperature_07_Mean_cell={AirTemperature_07_struct.Mean}';
%--
% �饭���a�Ŧb0CM
SoilTemperatureAt0cm_07_struct=[report_month_07_struct.data.dts.SoilTemperatureAt0cm];
SoilTemperatureAt0cm_07_Mean_cell={SoilTemperatureAt0cm_07_struct.Mean}';
%--
% �饭���a�Ŧb50CM
SoilTemperatureAt50cm_07_struct=[report_month_07_struct.data.dts.SoilTemperatureAt50cm];
SoilTemperatureAt50cm_07_Mean_cell={SoilTemperatureAt50cm_07_struct.Mean}';
%--
% �饭���a�Ŧb0CM
SoilTemperatureAt100cm_07_struct=[report_month_07_struct.data.dts.SoilTemperatureAt100cm];
SoilTemperatureAt100cm_07_Mean_cell={SoilTemperatureAt100cm_07_struct.Mean}';
%--
% �X��
all_07_cell=[DataDate_07_cell,DataDate_07_datenum_cell,Precipitation_07_Accumulation_cell,AirTemperature_07_Mean_cell,SoilTemperatureAt0cm_07_Mean_cell,SoilTemperatureAt50cm_07_Mean_cell,SoilTemperatureAt100cm_07_Mean_cell];
%--
% �Ƨ�
all_07_cell=all_07_cell(sorted_DataDate_07_datenum_array_index,:);
%--
all_07_cell_header={'���','datenum','��ֿn�B�q[mm]','�饭�����[�J]','�饭���a�Ŧb0CM[�J]','�饭���a�Ŧb50CM[�J]','�饭���a�Ŧb100CM[�J]'};
%-------------------------------------------------

%-------------------------------------------------
% �A�X��
all_0607_cell=[all_06_cell;all_07_cell];
%-------------------------------------------------

%-------------------------------------------------
% ø��
figure('outerposition',[51,51,1296,814]);%R2014a:[51,51,1296,814]->1280x720
movegui(gcf,'center')
set(gcf,'color',[1,1,1])
%
subplot(2,1,1)
temp_x=[all_0607_cell{1:14,2}]';
temp_y=[all_0607_cell{1:14,3}]';
bar(temp_x,temp_y)

datetick('x','yyyy-mm-dd')
set(gca,'XTick',[min(temp_x):max(temp_x)])

set(gca,'XTickLabel',{datestr(get(gca,'XTick'),'yyyy-mm-dd')})
xlim([min(temp_x),max(temp_x)])

title([' 20240601-20240614 �ˤl�� ��ֿn�B�q[mm]'])
% xlabel('Time')
ylabel('Precipitation[mm]')
xticklabel_rotate
subplot(2,1,2)
temp_x=[all_0607_cell{1:14,2}]';
temp_y1=[all_0607_cell{1:14,4}]';
temp_y2=[all_0607_cell{1:14,5}]';
temp_y3=[all_0607_cell{1:14,6}]';
temp_y4=[all_0607_cell{1:14,7}]';
plot(temp_x,[temp_y1,temp_y2,temp_y3,temp_y4])
legend('�饭�����','�饭���a�Ŧb0CM','�饭���a�Ŧb50CM','�饭���a�Ŧb100CM','Orientation','horizontal')

datetick('x','yyyy-mm-dd')
set(gca,'XTick',[min(temp_x):max(temp_x)])

set(gca,'XTickLabel',{datestr(get(gca,'XTick'),'yyyy-mm-dd')})
xlim([min(temp_x),max(temp_x)])
ylim([min([temp_y1;temp_y2;temp_y3;temp_y4])-2,max([temp_y1;temp_y2;temp_y3;temp_y4])+2])
title([' 20240601-20240614 �ˤl�� �ū�[�J]'])
xlabel('Time')
ylabel('�ū�[�J]')
xticklabel_rotate

%--
temp_frame=getframe(gcf);
imwrite(temp_frame.cdata,['20240601-20240614_�ˤl��_720p.png']);    
