
#define PUSH_PIN 23
#define READY_VOLTAGE 26      
#define READY_PSU  22                                                                                                                                                                                    
#define OFF_VOLTAGE 25
#define DATA 21
#define READY_PIN_CURRENT_POS 13
#define READY_PIN_CURRENT_NEG 12
#define RESET 14
#define REF_EXTERNAL 18
#define REF_PSU_NEG 19
#define REF_PSU_POS 5
#define OFF_PSU 17